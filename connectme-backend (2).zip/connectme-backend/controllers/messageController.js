const Conversation = require('../models/Conversation');
const Message = require('../models/Message');

// GET /api/messages/conversations
const getConversations = async (req, res) => {
  try {
    const conversations = await Conversation.find({ participants: req.session.userId })
      .sort({ updatedAt: -1 })
      .populate('participants', 'username profilePicture isOnline lastSeen')
      .populate('lastMessage');
    res.json({ conversations });
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch conversations.', error: err.message });
  }
};

// POST /api/messages/conversations  { participantId } -> get or create 1-1 conversation
const getOrCreateConversation = async (req, res) => {
  try {
    const { participantId } = req.body;
    const myId = req.session.userId;

    let conversation = await Conversation.findOne({
      isGroup: false,
      participants: { $all: [myId, participantId], $size: 2 },
    }).populate('participants', 'username profilePicture isOnline lastSeen');

    if (!conversation) {
      conversation = await Conversation.create({ participants: [myId, participantId], isGroup: false });
      conversation = await conversation.populate('participants', 'username profilePicture isOnline lastSeen');
    }

    res.json({ conversation });
  } catch (err) {
    res.status(500).json({ message: 'Failed to start conversation.', error: err.message });
  }
};

// GET /api/messages/:conversationId?page=1&limit=30
const getMessages = async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 30;

    const messages = await Message.find({ conversation: req.params.conversationId })
      .sort({ createdAt: -1 })
      .skip((page - 1) * limit)
      .limit(limit)
      .populate('sender', 'username profilePicture');

    res.json({ messages: messages.reverse(), page });
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch messages.', error: err.message });
  }
};

// POST /api/messages/:conversationId/read
const markAsRead = async (req, res) => {
  try {
    await Message.updateMany(
      { conversation: req.params.conversationId, readBy: { $ne: req.session.userId } },
      { $addToSet: { readBy: req.session.userId } }
    );
    res.json({ message: 'Marked as read.' });
  } catch (err) {
    res.status(500).json({ message: 'Failed to mark as read.', error: err.message });
  }
};

module.exports = { getConversations, getOrCreateConversation, getMessages, markAsRead };
