const { toFileUrl } = require('../utils/fileUrl');

// POST /api/upload — used by chat (and anywhere else) that needs a raw
// file uploaded over REST first, then references the returned URL
// (e.g. inside a socket 'sendMessage' payload).
const uploadFile = (req, res) => {
  if (!req.file) return res.status(400).json({ message: 'No file uploaded.' });

  const type = req.file.mimetype.startsWith('video')
    ? 'video'
    : req.file.mimetype.includes('gif')
    ? 'gif'
    : 'image';

  res.status(201).json({
    url: toFileUrl(req.file.filename),
    publicId: req.file.filename,
    type,
  });
};

module.exports = { uploadFile };
