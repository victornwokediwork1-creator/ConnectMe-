const Group = require('../models/Group');
const Post = require('../models/Post');
const { toFileUrl } = require('../utils/fileUrl');

// POST /api/groups
const createGroup = async (req, res) => {
  try {
    const { name, description, privacy } = req.body;
    if (!name) return res.status(400).json({ message: 'Group name is required.' });

    const coverPhoto = req.file ? { url: toFileUrl(req.file.filename), publicId: req.file.filename } : undefined;

    const group = await Group.create({
      name,
      description,
      privacy,
      coverPhoto,
      creator: req.session.userId,
      members: [req.session.userId],
      admins: [req.session.userId],
    });

    res.status(201).json({ group });
  } catch (err) {
    res.status(500).json({ message: 'Failed to create group.', error: err.message });
  }
};

// GET /api/groups?mine=true
const getGroups = async (req, res) => {
  try {
    const filter = req.query.mine === 'true' ? { members: req.session.userId } : {};
    const groups = await Group.find(filter).sort({ createdAt: -1 }).populate('creator', 'username profilePicture');
    res.json({ groups });
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch groups.', error: err.message });
  }
};

// GET /api/groups/:id
const getGroup = async (req, res) => {
  try {
    const group = await Group.findById(req.params.id)
      .populate('members', 'username profilePicture isOnline')
      .populate('admins', 'username profilePicture');
    if (!group) return res.status(404).json({ message: 'Group not found.' });
    res.json({ group });
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch group.', error: err.message });
  }
};

// POST /api/groups/:id/join
const joinGroup = async (req, res) => {
  try {
    await Group.findByIdAndUpdate(req.params.id, { $addToSet: { members: req.session.userId } });
    res.json({ message: 'Joined group.' });
  } catch (err) {
    res.status(500).json({ message: 'Failed to join group.', error: err.message });
  }
};

// POST /api/groups/:id/leave
const leaveGroup = async (req, res) => {
  try {
    await Group.findByIdAndUpdate(req.params.id, {
      $pull: { members: req.session.userId, admins: req.session.userId },
    });
    res.json({ message: 'Left group.' });
  } catch (err) {
    res.status(500).json({ message: 'Failed to leave group.', error: err.message });
  }
};

// GET /api/groups/:id/posts
const getGroupPosts = async (req, res) => {
  try {
    const posts = await Post.find({ group: req.params.id })
      .sort({ createdAt: -1 })
      .populate('author', 'username profilePicture');
    res.json({ posts });
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch group posts.', error: err.message });
  }
};

module.exports = { createGroup, getGroups, getGroup, joinGroup, leaveGroup, getGroupPosts };
