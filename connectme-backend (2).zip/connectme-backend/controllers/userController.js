const User = require('../models/User');
const Post = require('../models/Post');
const { createNotification } = require('../utils/notify');
const { toFileUrl, deleteUploadedFile } = require('../utils/fileUrl');

// GET /api/users/:id
const getUserProfile = async (req, res) => {
  try {
    const user = await User.findById(req.params.id)
      .select('-password')
      .populate('followers', 'username profilePicture')
      .populate('following', 'username profilePicture');
    if (!user) return res.status(404).json({ message: 'User not found.' });
    res.json({ user });
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch profile.', error: err.message });
  }
};

// PUT /api/users/me
const updateProfile = async (req, res) => {
  try {
    const { username, bio } = req.body;
    const updates = {};
    if (username) updates.username = username;
    if (bio !== undefined) updates.bio = bio;

    const currentUser = await User.findById(req.session.userId);

    if (req.files?.profilePicture?.[0]) {
      const f = req.files.profilePicture[0];
      if (currentUser?.profilePicture?.publicId) deleteUploadedFile(currentUser.profilePicture.publicId);
      updates.profilePicture = { url: toFileUrl(f.filename), publicId: f.filename };
    }
    if (req.files?.coverPhoto?.[0]) {
      const f = req.files.coverPhoto[0];
      if (currentUser?.coverPhoto?.publicId) deleteUploadedFile(currentUser.coverPhoto.publicId);
      updates.coverPhoto = { url: toFileUrl(f.filename), publicId: f.filename };
    }

    const user = await User.findByIdAndUpdate(req.session.userId, updates, { new: true }).select('-password');
    res.json({ user });
  } catch (err) {
    res.status(500).json({ message: 'Failed to update profile.', error: err.message });
  }
};

// PUT /api/users/me/settings
const updateSettings = async (req, res) => {
  try {
    const { theme, privacy } = req.body;
    const update = {};
    if (theme) update['settings.theme'] = theme;
    if (privacy?.profileVisibility) update['settings.privacy.profileVisibility'] = privacy.profileVisibility;
    if (privacy?.messagePermission) update['settings.privacy.messagePermission'] = privacy.messagePermission;

    const user = await User.findByIdAndUpdate(req.session.userId, { $set: update }, { new: true }).select('-password');
    res.json({ user });
  } catch (err) {
    res.status(500).json({ message: 'Failed to update settings.', error: err.message });
  }
};

// POST /api/users/:id/follow
const followUser = async (req, res) => {
  try {
    const targetId = req.params.id;
    const myId = req.session.userId;
    if (targetId === myId) return res.status(400).json({ message: "You can't follow yourself." });

    await User.findByIdAndUpdate(myId, { $addToSet: { following: targetId } });
    await User.findByIdAndUpdate(targetId, { $addToSet: { followers: myId } });

    await createNotification({
      recipient: targetId,
      sender: myId,
      type: 'follow',
      io: req.io,
      onlineUsers: req.onlineUsers,
    });

    res.json({ message: 'Followed successfully.' });
  } catch (err) {
    res.status(500).json({ message: 'Failed to follow user.', error: err.message });
  }
};

// POST /api/users/:id/unfollow
const unfollowUser = async (req, res) => {
  try {
    const targetId = req.params.id;
    const myId = req.session.userId;

    await User.findByIdAndUpdate(myId, { $pull: { following: targetId } });
    await User.findByIdAndUpdate(targetId, { $pull: { followers: myId } });

    res.json({ message: 'Unfollowed successfully.' });
  } catch (err) {
    res.status(500).json({ message: 'Failed to unfollow user.', error: err.message });
  }
};

// GET /api/users/:id/posts
const getUserPosts = async (req, res) => {
  try {
    const posts = await Post.find({ author: req.params.id })
      .sort({ createdAt: -1 })
      .populate('author', 'username profilePicture');
    res.json({ posts });
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch user posts.', error: err.message });
  }
};

module.exports = { getUserProfile, updateProfile, updateSettings, followUser, unfollowUser, getUserPosts };
