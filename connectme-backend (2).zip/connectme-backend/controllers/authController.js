const User = require('../models/User');

// POST /api/auth/register
const register = async (req, res) => {
  try {
    const { username, email, password } = req.body;
    if (!username || !email || !password) {
      return res.status(400).json({ message: 'Username, email and password are required.' });
    }

    const existing = await User.findOne({ $or: [{ email }, { username }] });
    if (existing) {
      return res.status(409).json({ message: 'Username or email already in use.' });
    }

    const user = await User.create({ username, email, password });

    // Session-based login — store userId in session, NOT a JWT.
    req.session.userId = user._id.toString();

    res.status(201).json({ user: user.toSafeObject() });
  } catch (err) {
    res.status(500).json({ message: 'Registration failed.', error: err.message });
  }
};

// POST /api/auth/login
const login = async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email });
    if (!user) return res.status(401).json({ message: 'Invalid credentials.' });

    const match = await user.comparePassword(password);
    if (!match) return res.status(401).json({ message: 'Invalid credentials.' });

    user.isOnline = true;
    await user.save();

    req.session.userId = user._id.toString();

    res.json({ user: user.toSafeObject() });
  } catch (err) {
    res.status(500).json({ message: 'Login failed.', error: err.message });
  }
};

// POST /api/auth/logout
const logout = async (req, res) => {
  try {
    const userId = req.session.userId;
    if (userId) {
      await User.findByIdAndUpdate(userId, { isOnline: false, lastSeen: new Date() });
    }
    req.session.destroy((err) => {
      if (err) return res.status(500).json({ message: 'Logout failed.' });
      res.clearCookie('connect.sid');
      res.json({ message: 'Logged out.' });
    });
  } catch (err) {
    res.status(500).json({ message: 'Logout failed.', error: err.message });
  }
};

// GET /api/auth/me
const getMe = async (req, res) => {
  try {
    const user = await User.findById(req.session.userId);
    if (!user) return res.status(404).json({ message: 'User not found.' });
    res.json({ user: user.toSafeObject() });
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch session user.', error: err.message });
  }
};

module.exports = { register, login, logout, getMe };
