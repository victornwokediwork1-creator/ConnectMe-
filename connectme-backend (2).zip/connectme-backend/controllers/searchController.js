const User = require('../models/User');
const Post = require('../models/Post');
const Group = require('../models/Group');

// GET /api/search?q=term&type=all|users|posts|groups
const search = async (req, res) => {
  try {
    const { q = '', type = 'all' } = req.query;
    if (!q.trim()) return res.json({ users: [], posts: [], groups: [] });

    const regex = new RegExp(q, 'i');
    const result = { users: [], posts: [], groups: [] };

    if (type === 'all' || type === 'users') {
      result.users = await User.find({ username: regex }).select('username profilePicture bio').limit(15);
    }
    if (type === 'all' || type === 'posts') {
      result.posts = await Post.find({ content: regex })
        .populate('author', 'username profilePicture')
        .limit(15);
    }
    if (type === 'all' || type === 'groups') {
      result.groups = await Group.find({ name: regex }).limit(15);
    }

    res.json(result);
  } catch (err) {
    res.status(500).json({ message: 'Search failed.', error: err.message });
  }
};

module.exports = { search };
