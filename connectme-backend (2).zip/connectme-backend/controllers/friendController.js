const FriendRequest = require('../models/FriendRequest');
const User = require('../models/User');
const { createNotification } = require('../utils/notify');

// POST /api/friends/request/:userId
const sendFriendRequest = async (req, res) => {
  try {
    const recipient = req.params.userId;
    const sender = req.session.userId;
    if (recipient === sender) return res.status(400).json({ message: "Can't friend yourself." });

    const existing = await FriendRequest.findOne({ sender, recipient, status: 'pending' });
    if (existing) return res.status(409).json({ message: 'Request already sent.' });

    const request = await FriendRequest.create({ sender, recipient });

    await createNotification({
      recipient,
      sender,
      type: 'friend_request',
      io: req.io,
      onlineUsers: req.onlineUsers,
    });

    res.status(201).json({ request });
  } catch (err) {
    res.status(500).json({ message: 'Failed to send friend request.', error: err.message });
  }
};

// POST /api/friends/accept/:requestId
const acceptFriendRequest = async (req, res) => {
  try {
    const request = await FriendRequest.findById(req.params.requestId);
    if (!request) return res.status(404).json({ message: 'Request not found.' });
    if (String(request.recipient) !== req.session.userId) {
      return res.status(403).json({ message: 'Not authorized.' });
    }
    request.status = 'accepted';
    await request.save();

    await User.findByIdAndUpdate(request.sender, { $addToSet: { friends: request.recipient } });
    await User.findByIdAndUpdate(request.recipient, { $addToSet: { friends: request.sender } });

    res.json({ message: 'Friend request accepted.' });
  } catch (err) {
    res.status(500).json({ message: 'Failed to accept request.', error: err.message });
  }
};

// POST /api/friends/reject/:requestId
const rejectFriendRequest = async (req, res) => {
  try {
    const request = await FriendRequest.findById(req.params.requestId);
    if (!request) return res.status(404).json({ message: 'Request not found.' });
    if (String(request.recipient) !== req.session.userId) {
      return res.status(403).json({ message: 'Not authorized.' });
    }
    request.status = 'rejected';
    await request.save();
    res.json({ message: 'Friend request rejected.' });
  } catch (err) {
    res.status(500).json({ message: 'Failed to reject request.', error: err.message });
  }
};

// GET /api/friends/requests
const getFriendRequests = async (req, res) => {
  try {
    const requests = await FriendRequest.find({ recipient: req.session.userId, status: 'pending' }).populate(
      'sender',
      'username profilePicture'
    );
    res.json({ requests });
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch requests.', error: err.message });
  }
};

// GET /api/friends
const getFriends = async (req, res) => {
  try {
    const user = await User.findById(req.session.userId).populate('friends', 'username profilePicture isOnline');
    res.json({ friends: user.friends });
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch friends.', error: err.message });
  }
};

// DELETE /api/friends/:userId
const removeFriend = async (req, res) => {
  try {
    const myId = req.session.userId;
    const otherId = req.params.userId;
    await User.findByIdAndUpdate(myId, { $pull: { friends: otherId } });
    await User.findByIdAndUpdate(otherId, { $pull: { friends: myId } });
    res.json({ message: 'Friend removed.' });
  } catch (err) {
    res.status(500).json({ message: 'Failed to remove friend.', error: err.message });
  }
};

module.exports = {
  sendFriendRequest,
  acceptFriendRequest,
  rejectFriendRequest,
  getFriendRequests,
  getFriends,
  removeFriend,
};
