const Comment = require('../models/Comment');
const Post = require('../models/Post');
const { createNotification } = require('../utils/notify');

// POST /api/posts/:postId/comments
const addComment = async (req, res) => {
  try {
    const { content } = req.body;
    if (!content) return res.status(400).json({ message: 'Comment content is required.' });

    const post = await Post.findById(req.params.postId);
    if (!post) return res.status(404).json({ message: 'Post not found.' });

    const comment = await Comment.create({
      post: post._id,
      author: req.session.userId,
      content,
    });

    post.comments.push(comment._id);
    await post.save();

    await createNotification({
      recipient: post.author,
      sender: req.session.userId,
      type: 'comment',
      post: post._id,
      comment: comment._id,
      io: req.io,
      onlineUsers: req.onlineUsers,
    });

    const populated = await comment.populate('author', 'username profilePicture');
    res.status(201).json({ comment: populated });
  } catch (err) {
    res.status(500).json({ message: 'Failed to add comment.', error: err.message });
  }
};

// GET /api/posts/:postId/comments
const getComments = async (req, res) => {
  try {
    const comments = await Comment.find({ post: req.params.postId })
      .sort({ createdAt: 1 })
      .populate('author', 'username profilePicture');
    res.json({ comments });
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch comments.', error: err.message });
  }
};

// DELETE /api/comments/:id
const deleteComment = async (req, res) => {
  try {
    const comment = await Comment.findById(req.params.id);
    if (!comment) return res.status(404).json({ message: 'Comment not found.' });
    if (String(comment.author) !== req.session.userId) {
      return res.status(403).json({ message: 'Not authorized to delete this comment.' });
    }
    await Post.findByIdAndUpdate(comment.post, { $pull: { comments: comment._id } });
    await comment.deleteOne();
    res.json({ message: 'Comment deleted.' });
  } catch (err) {
    res.status(500).json({ message: 'Failed to delete comment.', error: err.message });
  }
};

// POST /api/comments/:id/like
const likeComment = async (req, res) => {
  try {
    const comment = await Comment.findById(req.params.id);
    if (!comment) return res.status(404).json({ message: 'Comment not found.' });
    const myId = req.session.userId;
    const liked = comment.likes.some((id) => String(id) === myId);
    if (liked) {
      comment.likes = comment.likes.filter((id) => String(id) !== myId);
    } else {
      comment.likes.push(myId);
    }
    await comment.save();
    res.json({ likes: comment.likes });
  } catch (err) {
    res.status(500).json({ message: 'Failed to like comment.', error: err.message });
  }
};

module.exports = { addComment, getComments, deleteComment, likeComment };
