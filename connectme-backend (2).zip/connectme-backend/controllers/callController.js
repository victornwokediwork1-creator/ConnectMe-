const Call = require('../models/Call');

// GET /api/calls/history
const getCallHistory = async (req, res) => {
  try {
    const myId = req.session.userId;
    const calls = await Call.find({ $or: [{ caller: myId }, { receiver: myId }, { participants: myId }] })
      .sort({ createdAt: -1 })
      .limit(50)
      .populate('caller', 'username profilePicture')
      .populate('receiver', 'username profilePicture');
    res.json({ calls });
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch call history.', error: err.message });
  }
};

// POST /api/calls  (fallback REST logging; primary flow happens via sockets)
const logCall = async (req, res) => {
  try {
    const { receiver, type, status, duration, isGroupCall, participants } = req.body;
    const call = await Call.create({
      caller: req.session.userId,
      receiver,
      type,
      status: status || 'ended',
      duration: duration || 0,
      isGroupCall: !!isGroupCall,
      participants: participants || [],
      startedAt: new Date(),
      endedAt: status === 'ended' ? new Date() : null,
    });
    res.status(201).json({ call });
  } catch (err) {
    res.status(500).json({ message: 'Failed to log call.', error: err.message });
  }
};

module.exports = { getCallHistory, logCall };
