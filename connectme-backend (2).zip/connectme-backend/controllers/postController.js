const Post = require('../models/Post');
const Comment = require('../models/Comment');
const User = require('../models/User');
const { createNotification } = require('../utils/notify');
const { toFileUrl, deleteUploadedFile } = require('../utils/fileUrl');

// POST /api/posts
const createPost = async (req, res) => {
  try {
    const { content, group } = req.body;
    const media = (req.files || []).map((f) => ({
      url: toFileUrl(f.filename),
      publicId: f.filename,
      type: f.mimetype.startsWith('video') ? 'video' : f.mimetype.includes('gif') ? 'gif' : 'image',
    }));

    if (!content && media.length === 0) {
      return res.status(400).json({ message: 'Post must have text or media.' });
    }

    const post = await Post.create({
      author: req.session.userId,
      content: content || '',
      media,
      group: group || null,
    });

    const populated = await post.populate('author', 'username profilePicture');
    res.status(201).json({ post: populated });
  } catch (err) {
    res.status(500).json({ message: 'Failed to create post.', error: err.message });
  }
};

// GET /api/posts/feed?page=1&limit=10
const getFeed = async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const me = await User.findById(req.session.userId);
    const authorIds = [...me.following, me._id];

    const posts = await Post.find({ author: { $in: authorIds }, group: null })
      .sort({ createdAt: -1 })
      .skip((page - 1) * limit)
      .limit(limit)
      .populate('author', 'username profilePicture')
      .populate({ path: 'comments', populate: { path: 'author', select: 'username profilePicture' } });

    res.json({ posts, page });
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch feed.', error: err.message });
  }
};

// GET /api/posts/:id
const getPost = async (req, res) => {
  try {
    const post = await Post.findById(req.params.id)
      .populate('author', 'username profilePicture')
      .populate({ path: 'comments', populate: { path: 'author', select: 'username profilePicture' } });
    if (!post) return res.status(404).json({ message: 'Post not found.' });
    res.json({ post });
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch post.', error: err.message });
  }
};

// PUT /api/posts/:id
const updatePost = async (req, res) => {
  try {
    const post = await Post.findById(req.params.id);
    if (!post) return res.status(404).json({ message: 'Post not found.' });
    if (String(post.author) !== req.session.userId) {
      return res.status(403).json({ message: 'Not authorized to edit this post.' });
    }
    post.content = req.body.content ?? post.content;
    post.edited = true;
    await post.save();
    res.json({ post });
  } catch (err) {
    res.status(500).json({ message: 'Failed to update post.', error: err.message });
  }
};

// DELETE /api/posts/:id
const deletePost = async (req, res) => {
  try {
    const post = await Post.findById(req.params.id);
    if (!post) return res.status(404).json({ message: 'Post not found.' });
    if (String(post.author) !== req.session.userId) {
      return res.status(403).json({ message: 'Not authorized to delete this post.' });
    }
    await Comment.deleteMany({ post: post._id });
    post.media.forEach((m) => deleteUploadedFile(m.publicId));
    await post.deleteOne();
    res.json({ message: 'Post deleted.' });
  } catch (err) {
    res.status(500).json({ message: 'Failed to delete post.', error: err.message });
  }
};

// POST /api/posts/:id/like
const likePost = async (req, res) => {
  try {
    const post = await Post.findById(req.params.id);
    if (!post) return res.status(404).json({ message: 'Post not found.' });

    const myId = req.session.userId;
    const alreadyLiked = post.likes.some((id) => String(id) === myId);

    if (alreadyLiked) {
      post.likes = post.likes.filter((id) => String(id) !== myId);
    } else {
      post.likes.push(myId);
      await createNotification({
        recipient: post.author,
        sender: myId,
        type: 'like',
        post: post._id,
        io: req.io,
        onlineUsers: req.onlineUsers,
      });
    }
    await post.save();
    res.json({ likes: post.likes, liked: !alreadyLiked });
  } catch (err) {
    res.status(500).json({ message: 'Failed to like/unlike post.', error: err.message });
  }
};

// POST /api/posts/:id/share
const sharePost = async (req, res) => {
  try {
    const post = await Post.findById(req.params.id);
    if (!post) return res.status(404).json({ message: 'Post not found.' });
    post.shares.addToSet(req.session.userId);
    await post.save();
    res.json({ shares: post.shares.length });
  } catch (err) {
    res.status(500).json({ message: 'Failed to share post.', error: err.message });
  }
};

module.exports = { createPost, getFeed, getPost, updatePost, deletePost, likePost, sharePost };
