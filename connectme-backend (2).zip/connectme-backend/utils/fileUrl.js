const path = require('path');
const fs = require('fs');

const UPLOAD_DIR = path.join(__dirname, '..', 'uploads');

// Converts a stored filename into a URL path the frontend can request
// (server.js serves /uploads as a static folder).
const toFileUrl = (filename) => `/uploads/${filename}`;

// Removes a file from disk when a post/profile picture/group cover is
// replaced or deleted. Safe to call even if the file is already gone.
const deleteUploadedFile = (filename) => {
  if (!filename) return;
  const filePath = path.join(UPLOAD_DIR, filename);
  fs.unlink(filePath, (err) => {
    if (err && err.code !== 'ENOENT') {
      console.error(`Failed to delete file ${filename}:`, err.message);
    }
  });
};

module.exports = { toFileUrl, deleteUploadedFile, UPLOAD_DIR };
