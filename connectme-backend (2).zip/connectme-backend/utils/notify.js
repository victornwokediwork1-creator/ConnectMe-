const Notification = require('../models/Notification');

/**
 * Creates a notification in the DB and emits it in real time if the
 * recipient is online. `io` and `onlineUsers` are passed in from the
 * socket layer so this helper can be called from plain REST controllers too.
 */
const createNotification = async ({
  recipient,
  sender,
  type,
  post = null,
  comment = null,
  message = null,
  io = null,
  onlineUsers = null,
}) => {
  if (String(recipient) === String(sender)) return null; // don't notify yourself

  const notification = await Notification.create({
    recipient,
    sender,
    type,
    post,
    comment,
    message,
  });

  const populated = await notification.populate('sender', 'username profilePicture');

  if (io && onlineUsers) {
    const socketId = onlineUsers.get(String(recipient));
    if (socketId) {
      io.to(socketId).emit('newNotification', populated);
    }
  }

  return populated;
};

module.exports = { createNotification };
