# ConnectMe — Backend

A social media platform backend: feed, profiles, follow/friends, real-time chat,
groups, notifications, search, and call signaling (WebRTC-ready).

## Stack
Node.js, Express, MongoDB/Mongoose, Socket.io, Multer (local disk storage), bcryptjs,
express-session + connect-mongo.

**No JWT anywhere.** Login stores `userId` in a server-side session
(`req.session.userId`); sessions persist in MongoDB via `connect-mongo`, so
logins survive server restarts and there's no client-managed token at all.

**No Cloudinary either.** All uploaded media (post images/videos, profile and
cover photos, group covers, chat media) is written straight to disk in
`/uploads` and served back as static files. Only the resulting URL and
filename are stored in MongoDB.

## Setup
```bash
npm install
cp .env.example .env   # fill in MONGODB_URI and SESSION_SECRET
npm run dev             # nodemon, requires a reachable MongoDB
```

The only external service you need is MongoDB (local `mongod` or a free
MongoDB Atlas cluster). No third-party media service required.

## Architecture notes

**Auth** — `controllers/authController.js` + `middleware/auth.js`. Register/login
set `req.session.userId`; `requireAuth` middleware checks it on every protected
route. Logout destroys the session server-side.

**Media** — `middleware/upload.js` uses `multer.diskStorage` to write files into
`/uploads` with a randomized filename, which `server.js` serves at
`GET /uploads/<filename>`. `utils/fileUrl.js` builds the URL to store in
MongoDB and deletes files from disk when a post/profile photo/group cover is
replaced or removed. There's also a generic `POST /api/upload` endpoint for
cases like chat media, where a file needs to be uploaded before being
referenced in a socket message.

**Heads up for deployment**: if you deploy this somewhere with an ephemeral
filesystem (e.g. most container platforms wipe disk on redeploy), uploaded
files in `/uploads` won't survive a redeploy or restart unless you attach a
persistent volume. For a quick local setup or a VM with persistent disk this
is fine as-is; for production-grade durability you'd want either a mounted
volume or to swap `middleware/upload.js` back to an object storage backend
(Cloudinary, S3, etc.) later — the rest of the app doesn't care, since
everything just consumes a `url` string from the media objects.

**Real-time layer** — `sockets/index.js` keeps an in-memory `Map<userId, socketId>`
of who's online. It's also wired into REST controllers via `req.io` /
`req.onlineUsers` (set in `server.js`), so a plain HTTP request like "like a post"
can still push a live notification to the post's author if they're online.

**Calls** — `Call` model + socket events (`callUser`, `answerCall`, `rejectCall`,
`endCall`, `iceCandidate`). This is signaling-only: it tracks call state and
relays messages between two clients but does not include actual WebRTC peer
connection code. Hooking up `RTCPeerConnection` on the frontend using these
events as the signaling channel is the natural next step.

## API surface (all under `/api`)
`/auth` register, login, logout, me
`/users/:id`, `/users/:id/posts`, `/users/me` (PUT), `/users/me/settings` (PUT),
`/users/:id/follow`, `/users/:id/unfollow`
`/posts` (CRUD), `/posts/feed`, `/posts/:id/like`, `/posts/:id/share`,
`/posts/:postId/comments`
`/comments/:id` (DELETE), `/comments/:id/like`
`/friends`, `/friends/requests`, `/friends/request/:userId`,
`/friends/accept/:requestId`, `/friends/reject/:requestId`
`/messages/conversations`, `/messages/:conversationId`
`/groups` (CRUD-ish), `/groups/:id/join`, `/groups/:id/leave`, `/groups/:id/posts`
`/notifications`, `/notifications/:id/read`, `/notifications/read-all`
`/search?q=&type=`
`/calls/history`, `/calls` (POST, fallback logging)
`/upload` (POST, generic file upload — returns `{url, publicId, type}`)

## Socket events
Client → server: `join`, `sendMessage`, `typing`, `stopTyping`, `joinConversation`,
`messageRead`, `callUser`, `answerCall`, `rejectCall`, `endCall`, `iceCandidate`
Server → client: `newMessage`, `typing`, `stopTyping`, `messagesRead`,
`newNotification`, `userOnline`, `userOffline`, `incomingCall`, `callAccepted`,
`callRejected`, `callEnded`, `iceCandidate`

## What's next
This is phase 1 of 2. Phase 2 is the React frontend (Context API state, feed,
profile, chat UI, groups, call UI, dark/light mode, IndexedDB media caching)
that consumes this API.
