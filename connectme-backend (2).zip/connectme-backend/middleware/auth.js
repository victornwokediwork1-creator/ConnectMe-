// Simple session-based auth — NO JWT anywhere in this app.
// Login sets req.session.userId; this middleware just checks it exists.

const requireAuth = (req, res, next) => {
  if (!req.session || !req.session.userId) {
    return res.status(401).json({ message: 'Not authenticated. Please log in.' });
  }
  next();
};

// Attaches req.userId if logged in, but does not block the request if not.
const optionalAuth = (req, res, next) => {
  req.userId = req.session ? req.session.userId : null;
  next();
};

module.exports = { requireAuth, optionalAuth };
