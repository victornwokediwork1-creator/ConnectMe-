const mongoose = require('mongoose');

const postSchema = new mongoose.Schema(
  {
    author: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    content: { type: String, default: '', maxlength: 5000 },
    media: [
      {
        url: String,
        publicId: String,
        type: { type: String, enum: ['image', 'video', 'gif'] },
      },
    ],
    likes: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
    comments: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Comment' }],
    shares: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
    group: { type: mongoose.Schema.Types.ObjectId, ref: 'Group', default: null },
    edited: { type: Boolean, default: false },
  },
  { timestamps: true }
);

postSchema.index({ content: 'text' });

module.exports = mongoose.model('Post', postSchema);
