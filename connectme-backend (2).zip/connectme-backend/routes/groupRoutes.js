const express = require('express');
const router = express.Router();
const { requireAuth } = require('../middleware/auth');
const upload = require('../middleware/upload');
const {
  createGroup,
  getGroups,
  getGroup,
  joinGroup,
  leaveGroup,
  getGroupPosts,
} = require('../controllers/groupController');

router.get('/', requireAuth, getGroups);
router.post('/', requireAuth, upload.single('coverPhoto'), createGroup);
router.get('/:id', requireAuth, getGroup);
router.post('/:id/join', requireAuth, joinGroup);
router.post('/:id/leave', requireAuth, leaveGroup);
router.get('/:id/posts', requireAuth, getGroupPosts);

module.exports = router;
