const express = require('express');
const router = express.Router();
const { requireAuth } = require('../middleware/auth');
const {
  sendFriendRequest,
  acceptFriendRequest,
  rejectFriendRequest,
  getFriendRequests,
  getFriends,
  removeFriend,
} = require('../controllers/friendController');

router.get('/', requireAuth, getFriends);
router.get('/requests', requireAuth, getFriendRequests);
router.post('/request/:userId', requireAuth, sendFriendRequest);
router.post('/accept/:requestId', requireAuth, acceptFriendRequest);
router.post('/reject/:requestId', requireAuth, rejectFriendRequest);
router.delete('/:userId', requireAuth, removeFriend);

module.exports = router;
