const express = require('express');
const router = express.Router();
const { requireAuth } = require('../middleware/auth');
const upload = require('../middleware/upload');
const {
  createPost,
  getFeed,
  getPost,
  updatePost,
  deletePost,
  likePost,
  sharePost,
} = require('../controllers/postController');
const { addComment, getComments } = require('../controllers/commentController');

router.get('/feed', requireAuth, getFeed);
router.post('/', requireAuth, upload.array('media', 10), createPost);
router.get('/:id', requireAuth, getPost);
router.put('/:id', requireAuth, updatePost);
router.delete('/:id', requireAuth, deletePost);
router.post('/:id/like', requireAuth, likePost);
router.post('/:id/share', requireAuth, sharePost);

router.post('/:postId/comments', requireAuth, addComment);
router.get('/:postId/comments', requireAuth, getComments);

module.exports = router;
