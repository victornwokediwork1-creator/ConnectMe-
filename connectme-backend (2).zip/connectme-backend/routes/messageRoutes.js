const express = require('express');
const router = express.Router();
const { requireAuth } = require('../middleware/auth');
const {
  getConversations,
  getOrCreateConversation,
  getMessages,
  markAsRead,
} = require('../controllers/messageController');

router.get('/conversations', requireAuth, getConversations);
router.post('/conversations', requireAuth, getOrCreateConversation);
router.get('/:conversationId', requireAuth, getMessages);
router.post('/:conversationId/read', requireAuth, markAsRead);

module.exports = router;
