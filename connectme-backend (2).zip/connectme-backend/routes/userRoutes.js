const express = require('express');
const router = express.Router();
const { requireAuth } = require('../middleware/auth');
const upload = require('../middleware/upload');
const {
  getUserProfile,
  updateProfile,
  updateSettings,
  followUser,
  unfollowUser,
  getUserPosts,
} = require('../controllers/userController');

router.get('/:id', requireAuth, getUserProfile);
router.get('/:id/posts', requireAuth, getUserPosts);
router.put(
  '/me',
  requireAuth,
  upload.fields([{ name: 'profilePicture', maxCount: 1 }, { name: 'coverPhoto', maxCount: 1 }]),
  updateProfile
);
router.put('/me/settings', requireAuth, updateSettings);
router.post('/:id/follow', requireAuth, followUser);
router.post('/:id/unfollow', requireAuth, unfollowUser);

module.exports = router;
