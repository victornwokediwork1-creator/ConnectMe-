const express = require('express');
const router = express.Router();
const { requireAuth } = require('../middleware/auth');
const { deleteComment, likeComment } = require('../controllers/commentController');

router.delete('/:id', requireAuth, deleteComment);
router.post('/:id/like', requireAuth, likeComment);

module.exports = router;
