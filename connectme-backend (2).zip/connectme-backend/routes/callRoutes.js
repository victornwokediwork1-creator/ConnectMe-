const express = require('express');
const router = express.Router();
const { requireAuth } = require('../middleware/auth');
const { getCallHistory, logCall } = require('../controllers/callController');

router.get('/history', requireAuth, getCallHistory);
router.post('/', requireAuth, logCall);

module.exports = router;
