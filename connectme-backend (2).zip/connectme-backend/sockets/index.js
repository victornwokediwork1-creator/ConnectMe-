const User = require('../models/User');
const Message = require('../models/Message');
const Conversation = require('../models/Conversation');
const Call = require('../models/Call');
const { createNotification } = require('../utils/notify');

// Map<userId, socketId> — shared with REST controllers via req.onlineUsers
const onlineUsers = new Map();

function initSockets(io) {
  io.on('connection', (socket) => {
    let currentUserId = null;

    // Client emits this right after connecting, with the logged-in user's id.
    socket.on('join', async (userId) => {
      if (!userId) return;
      currentUserId = userId;
      onlineUsers.set(userId, socket.id);
      socket.join(userId); // personal room, lets us emit to a user by id alone

      await User.findByIdAndUpdate(userId, { isOnline: true });
      io.emit('userOnline', { userId });
    });

    // ---------- CHAT ----------
    socket.on('sendMessage', async ({ conversationId, senderId, content, media }) => {
      try {
        const message = await Message.create({
          conversation: conversationId,
          sender: senderId,
          content: content || '',
          media: media || undefined,
          readBy: [senderId],
        });

        await Conversation.findByIdAndUpdate(conversationId, { lastMessage: message._id });

        const populated = await message.populate('sender', 'username profilePicture');
        const conversation = await Conversation.findById(conversationId);

        conversation.participants.forEach((participantId) => {
          io.to(String(participantId)).emit('newMessage', populated);
        });

        // Notify recipients who aren't the sender
        for (const participantId of conversation.participants) {
          if (String(participantId) !== String(senderId)) {
            await createNotification({
              recipient: participantId,
              sender: senderId,
              type: 'message',
              message: content?.slice(0, 80) || 'Sent media',
              io,
              onlineUsers,
            });
          }
        }
      } catch (err) {
        socket.emit('errorEvent', { message: 'Failed to send message.', error: err.message });
      }
    });

    socket.on('typing', ({ conversationId, userId }) => {
      socket.to(conversationId).emit('typing', { conversationId, userId });
    });

    socket.on('stopTyping', ({ conversationId, userId }) => {
      socket.to(conversationId).emit('stopTyping', { conversationId, userId });
    });

    socket.on('joinConversation', (conversationId) => {
      socket.join(conversationId);
    });

    socket.on('messageRead', async ({ conversationId, userId }) => {
      await Message.updateMany(
        { conversation: conversationId, readBy: { $ne: userId } },
        { $addToSet: { readBy: userId } }
      );
      io.to(conversationId).emit('messagesRead', { conversationId, userId });
    });

    // ---------- CALLS (signaling architecture — WebRTC offer/answer ready) ----------
    socket.on('callUser', async ({ callerId, receiverId, type, signalData, isGroupCall, participants }) => {
      const call = await Call.create({
        caller: callerId,
        receiver: receiverId,
        type,
        status: 'ringing',
        isGroupCall: !!isGroupCall,
        participants: participants || [],
      });

      io.to(receiverId).emit('incomingCall', {
        callId: call._id,
        callerId,
        type,
        signalData,
        isGroupCall,
      });
    });

    socket.on('answerCall', async ({ callId, signalData, to }) => {
      await Call.findByIdAndUpdate(callId, { status: 'accepted', startedAt: new Date() });
      io.to(to).emit('callAccepted', { callId, signalData });
    });

    socket.on('rejectCall', async ({ callId, to }) => {
      await Call.findByIdAndUpdate(callId, { status: 'rejected' });
      io.to(to).emit('callRejected', { callId });
    });

    socket.on('endCall', async ({ callId, to, duration }) => {
      await Call.findByIdAndUpdate(callId, { status: 'ended', endedAt: new Date(), duration: duration || 0 });
      io.to(to).emit('callEnded', { callId });
    });

    // WebRTC signaling passthrough (ICE candidates, renegotiation) — ready for full WebRTC later
    socket.on('iceCandidate', ({ to, candidate }) => {
      io.to(to).emit('iceCandidate', { candidate });
    });

    // ---------- DISCONNECT ----------
    socket.on('disconnect', async () => {
      if (currentUserId) {
        onlineUsers.delete(currentUserId);
        await User.findByIdAndUpdate(currentUserId, { isOnline: false, lastSeen: new Date() });
        io.emit('userOffline', { userId: currentUserId, lastSeen: new Date() });
      }
    });
  });
}

module.exports = { initSockets, onlineUsers };
